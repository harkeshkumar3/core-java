package com.game.math.poker;


public class TestCard
{
    public static void main(String[] args)
    {
        Card a;

        a = new Card( Card.CLUB, 1);
        System.out.println(a);
    }
}
